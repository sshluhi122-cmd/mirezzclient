// Нативное ядро клиента. Грузится внутрь процесса Minecraft.
// Поднимает локальный сервер 127.0.0.1:38475, через него меню (ClientMod.apk)
// включает/выключает модули. Ответ на любую команду заканчивается строкой "end".

#include <android/log.h>
#include <arpa/inet.h>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <sys/socket.h>
#include <thread>
#include <unistd.h>

#include "shadowhook.h"
#include "offsets.h"

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "ClientMod", __VA_ARGS__)

struct Vec3 { float x, y, z; };

// ---------- состояние ----------
static std::atomic<bool> g_freecam{false};
static std::atomic<float> g_speed{0.5f};
static std::mutex g_camMtx;
static Vec3 g_cam{0, 0, 0};
static bool g_camInit = false;

static std::mutex g_statusMtx;
static std::string g_status = "ожидание игры";

static void setStatus(const char* s) {
    std::lock_guard<std::mutex> l(g_statusMtx);
    g_status = s;
    LOG("%s", s);
}

// ---------- FreeCam ----------
// ВНИМАНИЕ: сигнатура - предположение (this, Vec3* out). Нужно сверить с реальной
// функцией в твоей версии игры и поправить под неё.
static void (*orig_getCameraPos)(void*, Vec3*) = nullptr;

static void hook_getCameraPos(void* self, Vec3* out) {
    orig_getCameraPos(self, out);
    std::lock_guard<std::mutex> l(g_camMtx);
    if (!g_freecam) { g_camInit = false; return; }
    if (!g_camInit) { g_cam = *out; g_camInit = true; }  // стартуем с позиции игрока
    *out = g_cam;
}

// ---------- установка хуков ----------
static uintptr_t findBase(const char* lib) {
    FILE* f = fopen("/proc/self/maps", "r");
    if (!f) return 0;
    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof line, f)) {
        if (strstr(line, lib)) { base = (uintptr_t)strtoull(line, nullptr, 16); break; }
    }
    fclose(f);
    return base;
}

static void installHooks() {
    uintptr_t base = 0;
    for (int i = 0; i < 120 && !(base = findBase("libminecraftpe.so")); ++i) sleep(1);
    if (!base) { setStatus("libminecraftpe.so не найдена"); return; }

    if (shadowhook_init(SHADOWHOOK_MODE_UNIQUE, false) != 0) {
        setStatus("ошибка инициализации ShadowHook");
        return;
    }
    if (OFF_GET_CAMERA_POS == 0) { setStatus("оффсет не задан (offsets.h)"); return; }

    void* stub = shadowhook_hook_sym_addr((void*)(base + OFF_GET_CAMERA_POS),
                                          (void*)hook_getCameraPos,
                                          (void**)&orig_getCameraPos);
    setStatus(stub ? "хук камеры установлен" : "не удалось поставить хук камеры");
}

// ---------- команды от меню ----------
static std::string handle(const std::string& cmd) {
    char name[32];
    int v;
    float a, b, c;
    std::string out;

    if (cmd == "list") {
        out += std::string("mod freecam ") + (g_freecam ? "1" : "0") + "\n";
        std::lock_guard<std::mutex> l(g_statusMtx);
        out += "hook " + g_status + "\n";
    } else if (sscanf(cmd.c_str(), "set %31s %d", name, &v) == 2) {
        if (!strcmp(name, "freecam")) g_freecam = (v != 0);
        out = "ok\n";
    } else if (sscanf(cmd.c_str(), "move %f %f %f", &a, &b, &c) == 3) {
        float s = g_speed;
        std::lock_guard<std::mutex> l(g_camMtx);
        if (g_camInit) { g_cam.x += a * s; g_cam.y += b * s; g_cam.z += c * s; }
        out = "ok\n";
    } else if (sscanf(cmd.c_str(), "speed %f", &a) == 1) {
        g_speed = a;
        out = "ok\n";
    } else {
        out = "err\n";
    }
    return out + "end\n";
}

static void server() {
    int s = socket(AF_INET, SOCK_STREAM, 0);
    int one = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(38475);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(s, (sockaddr*)&addr, sizeof addr) < 0 || listen(s, 2) < 0) {
        LOG("bind/listen failed");
        return;
    }
    for (;;) {
        int c = accept(s, nullptr, nullptr);
        if (c < 0) continue;
        FILE* f = fdopen(c, "r+");
        if (!f) { close(c); continue; }
        char buf[128];
        while (fgets(buf, sizeof buf, f)) {
            std::string cmd(buf);
            while (!cmd.empty() && (cmd.back() == '\n' || cmd.back() == '\r')) cmd.pop_back();
            std::string r = handle(cmd);
            fputs(r.c_str(), f);
            fflush(f);
        }
        fclose(f);
    }
}

__attribute__((constructor)) static void clientcore_init() {
    std::thread(server).detach();
    std::thread(installHooks).detach();
}
