#pragma once
#include <cstdint>

// Minecraft Bedrock 1.26.50, arm64-v8a.
// Смещение функции относительно базы libminecraftpe.so (находится в Ghidra/IDA).
// 0 = не задано, хук не ставится, в меню будет видно "оффсет не задан".
constexpr uintptr_t OFF_GET_CAMERA_POS = 0x0;
