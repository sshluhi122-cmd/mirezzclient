package com.clientmod

import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

/** Связь с нативным ядром внутри Minecraft (локальный сокет). */
object NativeLink {
    private var sock: Socket? = null
    private var rd: BufferedReader? = null
    private var wr: PrintWriter? = null
    private val pool = Executors.newSingleThreadExecutor()

    /** cb вызывается в фоновом потоке; null = нет связи с игрой. */
    fun request(cmd: String, cb: (List<String>?) -> Unit) {
        pool.execute { cb(sync(cmd)) }
    }

    private fun connect(): Boolean {
        if (sock?.isClosed == false && sock?.isConnected == true) return true
        return try {
            val s = Socket()
            s.connect(InetSocketAddress("127.0.0.1", 38475), 300)
            s.soTimeout = 1000
            sock = s
            rd = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
            wr = PrintWriter(s.getOutputStream(), true)
            true
        } catch (e: Exception) {
            sock = null
            false
        }
    }

    private fun sync(cmd: String): List<String>? {
        if (!connect()) return null
        return try {
            wr!!.println(cmd)
            val out = ArrayList<String>()
            while (true) {
                val l = rd!!.readLine() ?: throw IOException("closed")
                if (l == "end") break
                out += l
            }
            out
        } catch (e: Exception) {
            try { sock?.close() } catch (_: Exception) {}
            sock = null
            null
        }
    }
}
