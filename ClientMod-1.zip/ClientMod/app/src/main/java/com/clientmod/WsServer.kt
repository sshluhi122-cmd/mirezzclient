package com.clientmod

import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.Base64
import java.util.UUID
import kotlin.concurrent.thread

/**
 * Мини WebSocket-сервер для связи с игрой.
 * В мире (с включёнными читами) вводишь в чате: /connect 127.0.0.1:19131
 * После этого меню может отправлять в игру команды, например "cam:free On".
 */
object WsServer {
    const val PORT = 19131
    private const val GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
    private var server: ServerSocket? = null
    @Volatile private var client: Socket? = null

    val connected: Boolean get() = client?.isClosed == false

    @Synchronized
    fun start() {
        if (server != null) return
        val ss = try {
            ServerSocket(PORT, 1, InetAddress.getByName("127.0.0.1"))
        } catch (e: Exception) {
            return
        }
        server = ss
        thread(isDaemon = true) {
            while (!ss.isClosed) {
                try {
                    val s = ss.accept()
                    if (handshake(s)) {
                        try { client?.close() } catch (_: Exception) {}
                        client = s
                        readLoop(s)
                    } else {
                        s.close()
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun handshake(s: Socket): Boolean {
        val inp = s.getInputStream()
        val sb = StringBuilder()
        while (!sb.endsWith("\r\n\r\n")) {
            val b = inp.read()
            if (b < 0) return false
            sb.append(b.toChar())
            if (sb.length > 8192) return false
        }
        val key = Regex("Sec-WebSocket-Key:\\s*(.+)", RegexOption.IGNORE_CASE)
            .find(sb)?.groupValues?.get(1)?.trim() ?: return false
        val accept = Base64.getEncoder().encodeToString(
            MessageDigest.getInstance("SHA-1").digest((key + GUID).toByteArray())
        )
        val resp = "HTTP/1.1 101 Switching Protocols\r\n" +
            "Upgrade: websocket\r\nConnection: Upgrade\r\n" +
            "Sec-WebSocket-Accept: $accept\r\n\r\n"
        s.getOutputStream().apply { write(resp.toByteArray()); flush() }
        return true
    }

    /** Читаем и выбрасываем всё, что шлёт игра; нужно только чтобы заметить закрытие. */
    private fun readLoop(s: Socket) {
        val inp = s.getInputStream()
        try {
            while (true) {
                val b0 = inp.read()
                if (b0 < 0) break
                val b1 = inp.read()
                if (b1 < 0) break
                var len = (b1 and 0x7f).toLong()
                if (len == 126L) {
                    len = ((inp.read() shl 8) or inp.read()).toLong()
                } else if (len == 127L) {
                    len = 0
                    repeat(8) { len = (len shl 8) or inp.read().toLong() }
                }
                if ((b1 and 0x80) != 0) repeat(4) { inp.read() }
                var left = len
                while (left > 0) {
                    val n = inp.skip(left)
                    if (n <= 0) {
                        if (inp.read() < 0) return
                        left--
                    } else {
                        left -= n
                    }
                }
                if ((b0 and 0x0f) == 8) break
            }
        } catch (_: Exception) {
        } finally {
            try { s.close() } catch (_: Exception) {}
            if (client === s) client = null
        }
    }

    @Synchronized
    fun send(text: String): Boolean {
        val s = client ?: return false
        return try {
            val d = text.toByteArray(Charsets.UTF_8)
            val o = ByteArrayOutputStream()
            o.write(0x81)
            if (d.size < 126) {
                o.write(d.size)
            } else {
                o.write(126)
                o.write(d.size shr 8)
                o.write(d.size and 0xff)
            }
            o.write(d)
            s.getOutputStream().apply { write(o.toByteArray()); flush() }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Выполнить команду в игре (без слэша). Вызывать из фонового потока. */
    fun command(line: String): Boolean {
        val id = UUID.randomUUID().toString()
        return send(
            """{"header":{"version":1,"requestId":"$id","messageType":"commandRequest","messagePurpose":"commandRequest"},""" +
                """"body":{"version":1,"commandLine":"$line","origin":{"type":"player"}}}"""
        )
    }
}
