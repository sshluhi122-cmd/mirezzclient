package com.clientmod

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.concurrent.thread

/** Плавающая кнопка "C" поверх игры + панель с переключателями модулей. */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var modules: LinearLayout
    private lateinit var status: TextView
    private lateinit var wsStatus: TextView
    private lateinit var lp: WindowManager.LayoutParams
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("c", "Mirez Client", NotificationManager.IMPORTANCE_LOW))
        startForeground(
            1,
            Notification.Builder(this, "c")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .setContentTitle("Mirez Client работает")
                .build()
        )
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        WsServer.start()
        buildUi()
    }

    override fun onDestroy() {
        try { wm.removeView(root) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun holdButton(label: String, dx: Float, dy: Float, dz: Float): Button {
        val b = Button(this).apply { text = label; textSize = 12f }
        val tick = object : Runnable {
            override fun run() {
                NativeLink.request("move $dx $dy $dz") {}
                ui.postDelayed(this, 50)
            }
        }
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> ui.post(tick)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> ui.removeCallbacks(tick)
            }
            true
        }
        return b
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        v.forEach { addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val bubble = ImageView(this).apply {
            setImageResource(R.drawable.ic_logo_bubble)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        }

        status = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 12f }
        wsStatus = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 12f }
        modules = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val seek = SeekBar(this).apply {
            max = 30
            progress = 5
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    NativeLink.request("speed ${(p + 1) / 10f}") {}
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        val refresh = Button(this).apply {
            text = "Обновить"
            setOnClickListener { refresh() }
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = bg(0xE6202020.toInt(), 12)
            layoutParams = LinearLayout.LayoutParams(dp(260), LinearLayout.LayoutParams.WRAP_CONTENT)
            addView(TextView(context).apply { text = "Mirez Client"; setTextColor(Color.WHITE); textSize = 16f })
            addView(status)
            addView(modules)
            addView(TextView(context).apply { text = "FreeCam-аддон"; setTextColor(Color.WHITE); textSize = 14f })
            addView(wsStatus)
            addView(Switch(context).apply {
                text = "FreeCam (аддон)"
                setTextColor(Color.WHITE)
                setOnCheckedChangeListener { _, on ->
                    thread {
                        val ok = WsServer.command(if (on) "cam:free On" else "cam:free Off")
                        ui.post { updateWs(ok) }
                    }
                }
            })
            addView(TextView(context).apply { text = "FreeCam: движение"; setTextColor(Color.WHITE); textSize = 12f })
            addView(row(holdButton("←", -1f, 0f, 0f), holdButton("→", 1f, 0f, 0f),
                        holdButton("↑", 0f, 0f, -1f), holdButton("↓", 0f, 0f, 1f)))
            addView(row(holdButton("▲ вверх", 0f, 1f, 0f), holdButton("▼ вниз", 0f, -1f, 0f)))
            addView(TextView(context).apply { text = "Скорость"; setTextColor(Color.WHITE); textSize = 12f })
            addView(seek)
            addView(refresh)
        }

        root.addView(bubble)
        root.addView(panel)

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 200 }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - downX).toInt()
                    val my = (e.rawY - downY).toInt()
                    if (Math.abs(mx) > 10 || Math.abs(my) > 10) moved = true
                    lp.x = startX + mx; lp.y = startY + my
                    wm.updateViewLayout(root, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) toggle()
            }
            true
        }

        wm.addView(root, lp)
    }

    private fun toggle() {
        if (panel.visibility == View.VISIBLE) {
            panel.visibility = View.GONE
        } else {
            panel.visibility = View.VISIBLE
            refresh()
        }
    }

    private fun updateWs(lastOk: Boolean = true) {
        wsStatus.text = when {
            !WsServer.connected -> "Не подключено. В чате игры введи: /connect 127.0.0.1:19131"
            !lastOk -> "Команда не отправилась"
            else -> "Игра подключена"
        }
    }

    private fun refresh() {
        updateWs()
        NativeLink.request("list") { lines -> ui.post { apply(lines) } }
    }

    private fun apply(lines: List<String>?) {
        modules.removeAllViews()
        if (lines == null) {
            status.text = "Нет связи с игрой. Запусти пропатченный Minecraft и нажми «Обновить»."
            return
        }
        for (l in lines) {
            val p = l.split(" ", limit = 3)
            when (p[0]) {
                "mod" -> modules.addView(Switch(this).apply {
                    text = p[1]
                    isChecked = p[2] == "1"
                    setTextColor(Color.WHITE)
                    setOnCheckedChangeListener { _, on ->
                        NativeLink.request("set ${p[1]} ${if (on) 1 else 0}") {}
                    }
                })
                "hook" -> status.text = "Хук: " + p.drop(1).joinToString(" ")
            }
        }
    }
}
