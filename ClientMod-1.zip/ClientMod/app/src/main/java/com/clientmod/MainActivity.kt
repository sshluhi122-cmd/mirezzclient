package com.clientmod

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
        }
        col.addView(TextView(this).apply {
            text = "Mirez Client"
            textSize = 28f
            setPadding(0, 0, 0, 48)
        })
        fun btn(t: String, action: () -> Unit) {
            col.addView(Button(this).apply { text = t; setOnClickListener { action() } })
        }

        btn("1. Разрешить показ поверх других окон") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Включить меню") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала дай разрешение (кнопка 1)", Toast.LENGTH_SHORT).show()
            } else {
                startForegroundService(Intent(this, OverlayService::class.java))
            }
        }
        btn("3. Открыть Minecraft") {
            val i = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
            if (i != null) startActivity(i)
            else Toast.makeText(this, "Minecraft не найден", Toast.LENGTH_SHORT).show()
        }
        btn("4. Установить аддон FreeCam в Minecraft") {
            try {
                val dir = File(cacheDir, "share").apply { mkdirs() }
                val f = File(dir, "FreeCam_V3_4.mcaddon")
                assets.open("FreeCam_V3_4.mcaddon").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                val uri = FileProvider.getUriForFile(this, "com.clientmod.files", f)
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/octet-stream")
                    setPackage("com.mojang.minecraftpe")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            } catch (e: Exception) {
                Toast.makeText(this, "Не вышло: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        setContentView(col)
    }
}
